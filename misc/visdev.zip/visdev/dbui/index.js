var express         = require('express')
  , app             = express()
  //, appConfig       = require('./lib/config')(app)
  , server          = require('http').createServer(app)
  , io              = require('socket.io').listen(server)
  , path            = require('path')
  , fs              = require('fs')
  , ejs             = require('ejs-locals')
  , SessionSockets  = require('session.socket.io')
  , cookieParser    = express.cookieParser('0secret1sausage2')
  , sessionStore    = new express.session.MemoryStore({ reapInterval: 60000 * 10 })
  , sessionSockets  = new SessionSockets(io, sessionStore, cookieParser)
  , port            = process.env.PORT || 5558
  , appConfig       = {};



GLOBAL.app = app;


// app config
if (fs.existsSync('./config.json')) {
  appConfig = require('./config.json');
}
if (!appConfig.defaultDir) {
  appConfig.defaultDir = (process.env.HOME || process.env.HOMEPATH || process.env.USERPROFILE);
}
  

// initialize fs io connections
require('./lib/fs/socket')(sessionSockets);

// initialize proc io connections
require('./lib/proc/socket1')(sessionSockets);

// register .html extension
app.engine('html', ejs);

// configure app
app.configure(function() {
  app.set('config', appConfig);
  app.set('port', port);
  app.set('views', path.join(__dirname, 'views'));
  app.set('view engine', 'html');
  app.use(cookieParser);
  app.use(express.session({
    store: sessionStore//,
    //secret: '5up3453werc43t',
    //key: 'connect.sid'
  }));
  app.use(express.bodyParser());
  app.use(express.methodOverride());
  app.use(express.favicon());
  app.use(express.compress());
  if (appConfig.users) {
    app.use(express.basicAuth(function(user, pass, callback) {
      callback(null, appConfig.users[user] == pass);
    }));
  }
  app.use(app.router);
  app.use(express.static(path.join(__dirname, 'public')));
});

app.configure('development', function() {
  app.use(express.logger('dev'));
  app.use(express.errorHandler());
});

// manage unhandled exceptions
process.on('uncaughtException', function(err) {
  console.error(err.stack);
  // todo: graceful shutdown
  throw err;
});


app.get('/', function(req, res) {
  res.render('index', { 
    appConfig: appConfig
  });
});
 
var fileutils = require('./lib/fileutils');
app.get('/file', function(req, res) {

  fileutils.readFile(req.query.path, function(err, fso) {

    if (err) {
      throw err;
    }

    var view = getView(fso);
    res.render('file/' + view, { 
      appConfig: appConfig, 
      fso: fso
    });
  });
  
  function getView(fso) {
    switch (fso.ext) {
      case '.db':
        return 'db';
      case '.json':
        if (fso.name === 'config.json' && fso.dir.slice(-3) === '.db') {
          return 'db';
        }
        return 'ace';
      default:
        return 'ace';
    }
  }
});

app.get('/proc', function(req, res) {
  res.render('proc', { 
    appConfig: appConfig
  });
});

// initialize server / start listening wsio
server.listen(port, function() {
  console.log('Listening on ' + port);
});

sessionSockets.on('connection', function (err, socket, session) {
  socket.emit('connection', session);
});