/*global define*/
define(['jquery', 'jqueryui', 'jquerycookie', 'socket', 'underscore', 'view/tmpls', 'common/modal', 'common/dialog', 'helpers'], function ($, jqueryui, jquerycookie, io, _, tmpls, modal, dialog) {
  $.cookie.json = true;

  // exports
  window.tmpls = tmpls;
  window.modal = modal;
  window.dialog = dialog;
  window.io = io;
  window.socket = io.connect();
  
  //$(function() {
  //  require(['fs', 'app'/*, 'db'*/]);
  //});

});