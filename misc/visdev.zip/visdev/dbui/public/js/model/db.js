define(['underscore', 'model/base', 'model/schema', 'common/msg'], function (_, base, schema, Msg) {

  var staticTypes = 'String Boolean Number Date NestedDocument Array ForeignKey ObjectId Mixed Buffer'.split(' ');
  var childDocumentType = ['ChildDocument'];

  return _.extend({}, base, {
    id: null,
    name: null,
    schemas: null,
    initialize: function (data) {
      this.id = data.id;
      this.name = data.name;
      this.schemas = [];
      for (var i = 0; i < data.schemas.length; i++) {
        this.addSchema(data.schemas[i]);
      }
    },
    addSchema: function (data) {
      var s = this.createSchema();
      s.initialize(data);
      this.schemas.push(s);
      return s;
    },
    insertSchema: function (schema) {
      this.schemas.push(schema);
      return schema;
    },
    createSchema: function () {
      return Object.create(schema, {
        db: {
          writable: false,
          enumerable: false,
          value: this
        }
      });
    },
    getSchemaById: function (id) {
      return _.findWhere(this.schemas, { id: id});
    },
    removeSchema: function (schema) {
      this.schemas.splice(this.schemas.indexOf(schema), 1);
    },
    errors: function () {
      var errors = [];

      for (var i = 0; i < this.schemas.length; i++) {
        Array.prototype.push.apply(errors, this.schemas[i].errors());
      }

      return errors;
    },
    isValid: function () {
      return this.errors().length === 0;
    },
    validateSchemaName: function (name, ignoreSchema) {
      if (!name) return new Msg('Name cannot be blank. Please supply a name.');
      var dupes = _.find(this.schemas, function(s) {
        return s !== ignoreSchema && s.name.toLowerCase() === name.toLowerCase();
      });
      return dupes ? new Msg('Duplicate Schema name. Please supply a unique name.') : true;
    },
    isKeyReferenced: function(id) {
      return this.childKeys().filter(function(key) { 
        return key.ref() === id;
      });
    },
    staticTypes: staticTypes,
    childDocumentType: childDocumentType,
    allTypes: [].concat(staticTypes, childDocumentType),
    notInstalledSchemas: function () {
      return _.filter(this.schemas, function (schema) {
        return !schema.installed;
      });
    },
    installedSchemas: function () {
      return _.filter(this.schemas, function (schema) {
        return schema.installed;
      });
    },
    availableDocumentRefs: function () {
      return _.map(this.installedSchemas(), function (schema) {
        return { id: schema.id, name: schema.name };
      });
    },
    availableChildDocumentRefs: function () {
      return _.map(this.notInstalledSchemas(), function (schema) {
        return { id: schema.id, name: schema.name };
      });
    },
    childKeys: function() {
      var keys = [];
      for (var i = 0; i < this.schemas.length; i++) {
        Array.prototype.push.apply(keys, this.schemas[i].keys.childKeys());
      }
      return keys;
    },
    toJson: function() {
      return JSON.stringify(this, function(key, value) {
        if(this.propertyIsEnumerable(key) === false) {
          return;
        }
        return value;
      }, 2);
    }
  });

});
