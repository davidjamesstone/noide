/*global define*/

define(['underscore', 'model/base', 'model/def', 'common/msg'], function (_, base, def, Msg) {

  return _.extend({}, base, {
    keys: null,
    initialize: function (data) {
      this.name = data.name;
      this.define(data);
    },
    define: function (data) {
      this.type = data.type;
      this.def = Object.create(def, {
        key: {
          writable: false,
          enumerable: false,
          value: this
        }
      });
      this.def.initialize(data);
    },
    description: function () {
      var names = _.object(_.map(this.keys.schema.db.schemas, function(schema) {
        return [schema.id, schema.name];
      }));

      var def = this.def;
      var t = this.type;
      if (t === 'Array') {
        var ofT = def.oftype;
        if (ofT === 'ForeignKey') {
          return '[' + ofT + '<' + names[def.def.ref] + '>]';
        } else if (ofT === 'ChildDocument') {
          return '[' + ofT + '<' + names[def.def.ref] + '>]';
        } else {
          return '[' + ofT + ']';
        }
      } else if (t === 'ForeignKey') {
        return t + '<' + names[def.ref] + '>';
      } else {
        return t;
      }
    },
    ref: function () {
      if (this.type === 'ForeignKey') {
        return this.def.ref;
      } else if (this.type === 'Array' && this.def.oftype === 'ForeignKey') {
        return this.def.def.ref;
      } else if (this.type === 'Array' && this.def.oftype === 'ChildDocument') {
        return this.def.def.ref;
      } else {
        return;
      }
    },
    isNestedType: function() {
      return this.type == 'NestedDocument';
    },
    isNestedTypeArray: function() {
      return this.isArray() && this.def.oftype === 'NestedDocument';
    },
    isNested: function() {
      return this.isNestedType() || this.isNestedTypeArray();
    },
    isArray: function() {
      return this.type === 'Array';
    },
    childKeys: function() {
      if (this.isNestedType()) {
        return this.def.keys.childKeys();
      } else if (this.isNestedTypeArray()) {
        return this.def.def.keys.childKeys();
      }
      return null;
    },
    errors: function () {
      var errors = [];

      if (!this.name) {
        errors.push(new Msg('Name is required'));
      }

      var def = this.def;
      return def.errors ? errors.concat(def.errors()) : errors;
    }
  });

});