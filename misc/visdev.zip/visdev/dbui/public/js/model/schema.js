define(['underscore', 'model/base', 'model/keys'], function (_, base, keys) {

  return _.extend({}, base, {
    db: null,
    initialize: function (data) {
      this.id = data.id;
      this.name = data.name;
      this.installed = data.installed || false;
      this.keys = Object.create(keys, {
        schema: {
          writable: false,
          enumerable: false,
          value: this
        }
      });
      this.keys.initialize(data.keys.items);
    },
    errors: function () {
      return this.keys.errors();
    }, 
    childKeys: function() {
      return this.keys.childKeys();
    }
  });

});