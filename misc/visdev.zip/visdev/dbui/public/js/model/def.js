/*global define, require*/

define(['underscore', 'model/base', 'model/keys', 'common/msg'], function (_, base, keys, Msg) {

  // The 'keys' argument is a circular ref and may be undefined on initialization.
  // It's unused and here only to ensure proper module loading. require('keys') is used in place.
    
  var StringDef = function (data) {
    this.required = data.required;
    this.defaultValue = data.defaultValue;
    this.enumeration = data.enumeration;
    this.uppercase = data.uppercase;
    this.lowercase = data.lowercase;
    this.match = data.match;
    this.trim = data.trim;
  };

  var BooleanDef = function (data) {
    this.required = data.required;
    this.defaultValue = data.defaultValue;
  };

  var NumberDef = function (data) {
    this.required = data.required;
    this.defaultValue = data.defaultValue;
    this.min = data.min;
    this.max = data.max;
    this.errors = function () {
      var errors = [];
      var min = !isNaN(this.min) ? Number(this.min) : null;
      var max = !isNaN(this.max) ? Number(this.max) : null;
      var dflt = !isNaN(this.defaultValue) ? Number(this.defaultValue) : null;

      if (this.min && min === null) {
        errors.push(new Msg('Min value is not a number'));
      } else if ((min !== null && dflt !== null) && (dflt < min)) {
        errors.push(new Msg('The Default value should be greater than Min'));
      }

      if (this.max && max === null) {
        errors.push(new Msg('Max value is not a number'));
      } else if ((max !== null && dflt !== null) && (dflt > max)) {
        errors.push(new Msg('The Default value should be less than Max'));
      }

      if (this.defaultValue && dflt === null) {
        errors.push(new Msg('Default value is not a number'));
      }

      if (min !== null && max !== null) {
        if (max <= min) {
          errors.push(new Msg('Max value should be greater than Min'));
        }
      }

      return errors;
    };
  };

  var DateDef = function (data) {
    this.required = data.required;
    this.defaultValue = data.defaultValue;
  };

  var NestedDocumentDef = function (data, key) {
    this.required = data.required;
    this.keys = Object.create(require('model/keys'), {
      schema: {
        value: key.keys.schema,
        writable: false,
        enumerable: false
      }
    });
    this.keys.initialize(data.keys ? data.keys.items : []);

    this.errors = function () {
      return this.keys.errors();
    };
  };

  var ArrayDef = function (data, key) {
    this.define(data, key);
    this.errors = function () {
      return this.def.errors ? this.def.errors() : [];
    };
  };
  ArrayDef.prototype.define = function (data, key) {
    this.oftype = data.oftype;
    this.def = Object.create(p, {
      key: {
        writable: false,
        enumerable: false,
        value: key
      }
    });
    this.def.initialize(data);
  };

  var ForeignKeyDef = function (data) {
    this.required = data.required;
    this.ref = data.ref;
  };

  var MixedDef = function (data) {
    this.required = data.required;
  };

  var ObjectIdDef = function (data) {
    this.required = data.required;
    this.auto = data.auto;
  };

  var BufferDef = function (data) {
    this.required = data.required;
    this.ref = data.ref;
  };

  var ChildDocumentDef = function (data) {
    this.ref = data.ref;
  };

  function factoryDef(data, key) {
    var type = (data.type || data.oftype).toLowerCase();
    var def = data.def;
    switch (type) {
    case 'string':
      return new StringDef(def);
    case 'boolean':
      return new BooleanDef(def);
    case 'number':
      return new NumberDef(def);
    case 'date':
      return new DateDef(def);
    case 'nesteddocument':
      return new NestedDocumentDef(def, key);
    case 'array':
      return new ArrayDef(def, key);
    case 'foreignkey':
      return new ForeignKeyDef(def);
    case 'objectid':
      return new ObjectIdDef(def);
    case 'mixed':
      return new MixedDef(def);
    case 'buffer':
      return new BufferDef(def);
    case 'childdocument':
      return new ChildDocumentDef(def);
    default:
      throw new Error('Type not supported');
    }
  }

  var p = _.extend({}, base, {
    key: null,
    initialize: function (data) {
      _.extend(this, factoryDef(data, this.key));
    }    
  });

  return p;

});