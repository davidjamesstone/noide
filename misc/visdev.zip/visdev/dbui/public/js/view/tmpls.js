/*global define*/
define(['jquery', 'underscore', 'text!html/tmpls.html'], function ($, _, tmpls) {
  var templates = {};
  $(tmpls).filter('script').each(function () {
    var $this = $(this);
    var name = $this.attr('id').replace('-tpl', '').replace('-def', '');
    templates[name] = _.template($this.html());
  });

  _.extend(templates, {
    helpers: {
      sortDir: function(a, b) {
        if (a.isDirectory !== b.isDirectory) {
          return a.isDirectory ? -1 : 1;
        } else {
          return a.name.toLowerCase() < b.name.toLowerCase() ? -1 : a.name.toLowerCase() > b.name.toLowerCase() ? 1 : 0;
        }
      },
      getFsoIcon: function(data, loaded) {
        if (data.isDirectory) {
          if (data.name === '.git') {
            return 'icon-github';
          } else if (data.name.endsWith('.api')) {
            return 'icon-switch2';
          }
        }
        if (data.name.endsWith('.db')) {
          return 'icon-database';
        }
        return loaded ? 'icon-folder-open' : 'icon-folder';
      },
      getFsoClasses: function(data, loaded) {
        if (data.isDirectory) {
          if (data.name === '.git') {
            return 'special git';
          } else if (data.name.endsWith('.api')) {
            //return 'special';
          }
        }
        if (data.name.endsWith('.db')) {
          //return 'special';
        }
      }
    }
  });
  return templates;
});
