/*global define, window */
define(['common/utils', 'common/dialog', 'plugins/index', 'plugins/wrkspc/index', 'procpool', 'masonry', 'autumn'], function (utils, dialog, plugins, wrkspcplugins, PP, Masonry, autumn) {

  window.VD.PP = PP;

  $('#app').on('mousedown', '.resize.panel', function(e) {
    $(this).css('z-index', utils.getNextZIndex());
  });

  
  $('#ws').on('click', '.add-iframe', function(e) {
    e.preventDefault();
    var $this = $(this);
    var href = $this.attr('href');
    var title = $this.attr('title');
    dialog.prompt({
      title: 'Add iframe',
      message: 'Enter Url',
      defaultValue: href,
      placeholder: 'Enter Url'
    }, function(value) {
      if (value) {
        addiframe(value, title || value);
      }
    });
    return false;
  });

  $('#ws').on('dblclick', '.panel-heading', function() {
    $(this).closest('.resize').toggleClass('maximized');
  });

  
      
  function addiframe(href, title) {
    var $file = $('<iframe>')
    .addClass('stretch')
    .attr({ 
      src: href
    }).css({ 
      border: 'none'
    });

    //var $editor = $('<div>').ace({ 
    //  path: path, 
    //  ext: ext, 
    //  pathid: pathid 
    //});

    var $panel = $('<div>').panel({
      title: title || href,
      body: $file
    });

    $panel.appendTo($('#ws'));
  }

  //addiframe('http://devdocs.io', 'devdocs.io');
  //addiframe('http://localhost:8448/#/repository?path=C%3A%5CProjects%5CNode%5Ctest', 'ungit');
  //addiframe('http://localhost:8080/debug?port=5858', 'node --debug 5858');

  $('#procs').procs();
  PP.connect();
  //$('<div>').appendTo(document.body).panel();

  //window.$procs = $('#procs').procs();

  //window.$app.on('exit', function() { alert('')});
 // window.$app = $('#app1').term({});
//  window.$app = $('#app').app();

//  var components = [
//    {
//      type: 'fso', 
//      name: 'js',
//      color: 'js',
//      icon: 'icon-file',
//      data: {
//        path: 'C:\\Projects\\Node\\works\\index.js',
//        dir: 'C:\\Projects\\Node\\works',
//        ext: '.js',
//        isDirectory: false
//      }
//    },
//    {
//      type: 'fso', 
//      name: 'js',
//      color: 'js',
//      icon: 'icon-file',
//      data: {
//        path: 'C:\\Projects\\Node\\works\\index.js',
//        dir: 'C:\\Projects\\Node\\works',
//        ext: '.js',
//        isDirectory: false
//      }
//    }
      
//  ];
  
//for (var i = 0; i < components.length; i++) {
//  $app.app('insert', components[i]);
//}
//socket.on('term-pids', function(pids) {
//  for (var i = 0; i < pids.length; i++) {
//    $app.app('insert', 
//    {
//      type: 'term', 
//      name: 'term',
//      color: 'term',
//      icon: 'icon-pencil',
//      data: {
//        pid: pids[i],
//        pwd: 'C:\\Projects\\Node',
//        run: ''
//      }
//    });
//  }
//});

//  //.resizable().on('resize', function () { console.log('sds') });


//    //$main.find('.box').resizable({
//    //  stop: function( event, ui ) {
//    //    //console.log('sds'); execMasonry();
//    //  }
//    //});


//  var execMasonry = function() {
//    var msnry = new Masonry($main.get(0), {
//      // options
//      //columnWidth: 100,
//      animate: true
//    });
//    colorAppItems($main.find('.box'));
//  }

//  var colorAppItems = function($items) {
//    $items.autumn('backgroundColor', 'data-color');
//  }

//  //// trigger masonry
//  //$main.masonry({
//  //  columnWidth: 100,
//  //  animate: true
//  //});

//  //$('.box').click(function() {
//  //  var $this = $(this),
//  //      size = $this.hasClass('large') ?
//  //        { width: 90, height: 90 } :
//  //        { width: 190, height: 190 };
//  //  $this.toggleClass('large').animate( size, execMasonry );
//  //});

//  colorAppItems($app.find('.box'));
////  execMasonry();



});
