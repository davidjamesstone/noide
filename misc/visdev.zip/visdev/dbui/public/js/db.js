/*global define $ _ */
define(['jsplumb', 'model/db', 'model/key', 'common/msg', 'common/utils', 'common/dialog'], function (jsplumb, db, key, Msg, utils, dialog) {

  $.widget('vui.db', {
    options: {
      path: null,
      dir: null,
      name: null,
      ext: null
    },

    _create: function() {

      var options = this.options,
        data = options.data,
        path = options.path,
        ext = options.ext || '',
        socket = options.socket;

    
        // initialize db model object
        var model = Object.create(db);
        model.initialize(
          data && Array.isArray(data.schemas) 
            ? data 
            : { schemas: [] }
        );

  
        // make schema panels draggable
        var draggable = {
          handle: '.panel-heading',
          stop: function(e, ui) {
            var dbState = $.cookie('db-state') || {};
            if (!dbState[model.id]) {
              dbState[model.id] = {};
            }
            dbState[model.id][this.id] = ui.position;
            $.cookie('db-state', dbState, { expires: 365 });
          }
        };

        // main UI container
        var $body = $(document.body);
        var $main = this.element;
        var $keymenu = $(tmpls.keymenu({ isNested: true }))
        $keymenu.appendTo($main);

        // ui element factories
        function createKey(key, activeKey) {
          if (!key) return;
          var $key = $('<li class="key">' + tmpls.key({ key: key, isActive: key === activeKey})).data('key', key);
          if (key.isNested()) {
            $key.append(createKeys(key.isArray() ? key.def.def.keys : key.def.keys));
          }
          return $key;
        }

        function createKeys(keys, activeKey) {
          var $keys = $('<ul class="keys">');
          for (var i = 0; i < keys.items.length; i++) {
            $keys.append(createKey(keys.items[i], activeKey));
          }
          return $keys;
        }

        function createSchema(schema) {
          var $schema = $(tmpls.schema(schema));
          $schema.find('.panel-body').append(createKeys(schema.keys));
          return $schema;
        }

        (function createSchemas($el) {
          for (var i = 0; i < model.schemas.length; i++) {
            $el.append(createSchema(model.schemas[i]));
          }
        })($main);
    
        // register event handlers
        (function attachEvents($el) {
      
          function triggerModelChanged() {
            $el.trigger('modelchanged');
          }

          function hideAllTooltips() {
            $('.tooltip').hide();
          }
      
          function hideAllPopovers(otherThan) {
            //$keymenu.hide();
          }
      
          function createActiveRecord(activeKey, $activeKey) {
            return Object.create({
              cloneKey: function() {
                var o = Object.create(key, {
                  keys: {
                    writable: false,
                    enumerable: false,
                    value: this.key.keys
                  }
                });
                o.initialize(this.key.toJson());
                return o;
              }
              }, {
                key: {
                  writable: false,
                  value: activeKey
                }, 
                $key: {
                  writable: false,
                  value: $activeKey
                }
              }); 
          }

          /* model events */
          $el
          .on('contextmenu', '.key-header', function(e) {
            e.preventDefault();

            var $this = $(this);
            var $schema = $this.closest('.schema');
            var $key = $this.closest('.key');
            var key = $key.data('key');
        
            // set up active record
            var activeRecord = createActiveRecord(key, $key);
            $keymenu.data('active-record', activeRecord);
        
            // make this the active row
            $this.addClass('active');
            $schema.find('.key-header').not(this).removeClass('active');

            // position menu
            var $addinside = $keymenu.find('.add-key[data-location="inside"]');
            $addinside[key.isNested() ? 'show' : 'hide']();
            $keymenu.css({ top: e.pageY - 5, left: e.pageX - 5 }).show();
            //$keymenu.position({
            //  of: $this,
            //  my: 'right',
            //  at: 'left',
            //  collision: 'flipfit'
            //})[key.isNested() ? 'addClass' : 'removeClass']('is-nested').show();
            return false;
          })
          .on('mouseleave', '.key-menu', function(e) { 
	          $keymenu.hide(); 
          })
          .on('click', '.add-schema', function (e) {
            e.preventDefault();

            var schema = model.createSchema();
            schema.initialize({
              id: utils.getuid(),
              name: '',
              installed: true,
              keys: { 
                items: [{
                  "name":"newkey",
                  "type":"String",
                  "def":{
                      "required": true
                  }
                }] 
              }
            });
        
            dialog.custom({ 
              title: 'Add schema', 
              content: $(tmpls.schemaform(schema)).data('schema', schema)
            });

            return false;
          })
          .on('click', '.save', function (e) {
            e.preventDefault();

            socket.emit('writefile', path, model.toJson());

            return false;
          })
          .on('click', '.edit-schema', function (e) {
            e.preventDefault();

            var $this = $(this);
            var $schema = $this.closest('.schema');
            var id = $schema.attr('id');
            var schema = model.getSchemaById(id);

            dialog.custom({ 
              title: 'Editing schema: ' + schema.name, 
              content: $(tmpls.schemaform(schema)).data('schema', schema)
            });

            return false;
          })
          .on('click', '.show-model-json', function (e) {
            var $this = $(this);

            function createDialog() {
              return dialog.alert({
                title: 'Schema JSON',
                message: '<pre>' + model.toJson() + '</pre>'
              });
            }

            var $dialog = createDialog();

            return false;
          })
          .on('click', '.delete-schema', function (e) {
            var $this = $(this);
            var $schema = $this.closest('.schema');
            var id = $schema.attr('id');
            var schema = model.getSchemaById(id);
            var references = model.isKeyReferenced(id);

            if (references.length) {
              return dialog.alert({ title: 'Delete schema', message: 'Unable to delete schema [' + schema.name + ']. First remove the ' + (references.length === 1 ? 'reference' : (references.length + ' references')) +  ' to it.' });
            } else {
              return dialog.confirm({ title: 'Delete schema', message: 'Are you sure you want to delete schema [' + schema.name + ']' }, function(value) {
                if (value) {
                  model.removeSchema(schema);
                  $schema.remove();
                }
                return true;
              });
            }

            return false;
          })
          .on('click1', '.key-header', function (e) {
            $(this).removeClass('active');
            hideAllPopovers();
          })
          .on('click1', '.key-header:not(.active)', function (e) {
            e.preventDefault();

            var $this = $(this);
            var $schema = $this.closest('.schema');
            var $key = $this.closest('.key');
            var key = $key.data('key');
        
            // set up active record
            var activeRecord = createActiveRecord(key, $key);
            $keymenu.data('active-record', activeRecord);
        
            // make this the active row
            $this.addClass('active');
            $schema.find('.key-header').not(this).removeClass('active');

            // position menu
            $keymenu.position({
              of: $this,
              my: 'right',
              at: 'left',
              collision: 'flipfit'
            })[key.isNested() ? 'addClass' : 'removeClass']('is-nested').show();

            //$keymenu.css({ top: e.pageY, left: e.pageX })[key.isNested() ? 'addClass' : 'removeClass']('is-nested').show();

            return false;
          })
          .on('click', '.add-key', function (e) {
            e.preventDefault();

            var $this = $(this);
            var location = $this.data('location');
            var activeRecord = $keymenu.hide().data('active-record');

            var keys = null;
            if (location === 'inside') {
              keys = activeRecord.key.isNestedType() ? 
                activeRecord.key.def.keys : 
                activeRecord.key.def.def.keys;
            } else {
              keys = activeRecord.key.keys;
            }

            var tempkey = Object.create(key, {
              keys: {
                writable: false,
                enumerable: false,
                value: keys
              }
            });
            tempkey.initialize({
              name: '',
              type: 'String',
              def: {}
            });

            // and add tempkey to .key-editor data (for 'type/oftype' change purposes)
            var $editor = $(tmpls.keyform(tempkey)).data('tempkey', tempkey);

            $editor.on('submit', 'form', function (e) {
              e.preventDefault();
          
              var $this = $(this);  

              function addKey() {        
                var tempdef = tempkey.isArray() ? tempkey.def.def : tempkey.def;
                var $key = activeRecord.$key;
                var $keys = $key.closest('.keys');

                function getFormValue($val) {
                  if ($val.is('input[type=checkbox]')) {
                    return $val.prop('checked');
                  } else {
                    return $val.val();
                  }
                }

                var $vals = $this.find('input, select:not([name=type], [name=oftype])');
                for (var i = 0; i < $vals.length; i++) {
                  var $val = $vals.eq(i);

                  var name = $val.attr('name');
                  if (!name) throw new Error(); // todo: rmeove
                  if (name === 'name') {
                    tempkey[name] = $val.val();
                  } else {
                    tempdef[name] = getFormValue($val);
                  }
                }

                var errors = tempkey.errors();

                // check for duplicate names
                var dupes = tempkey.keys.items.filter(function (item) {
                  return item !== key && item.name.toLowerCase() === tempkey.name.toLowerCase();
                });
                // and append to errors
                if (dupes.length) {
                  errors.splice(0, 0, new Msg('Duplicate key name'));
                }


                $editor.children('.alert').remove();
                if (errors.length) {  // show errors
                  $editor.prepend($(tmpls.errors(errors)));
                  return false;
                } else { // save and close

                  var $newkey;
                  if (location === 'above') {
                    tempkey.keys.insertKey(tempkey, keys.items.indexOf(activeRecord.key) - 1);
                    $newkey = createKey(tempkey).insertBefore($key);
                  } else if (location === 'below') {
                    tempkey.keys.insertKey(tempkey, keys.items.indexOf(activeRecord.key) + 1);
                    $newkey = createKey(tempkey).insertAfter($key);
                  } else if (location === 'inside') {
                    keys.insertKey(tempkey, keys.items.length);
                    $newkey = createKey(tempkey);
                    $key.find('> ul.keys').append($newkey);
                  }
                
                  // reshow $key popover
                  //$newkey.find('.key-header.active').click();
              

                  triggerModelChanged();

                  $editor.remove();
                  dialog.hide();

                  return true;
                }
              }
              addKey();

              return false;
            });

            // show editor
            dialog.custom({ 
              title: 'Add key',
              content: $editor
            });

            return false;
          })
          .on('click', '.edit-key', function (e) {
            var $this = $(this);
            var activeRecord = $keymenu.hide().data('active-record');
            var key = activeRecord.key;
            var tempkey = activeRecord.cloneKey();

            // and add tempkey to .key-editor data (for 'type/oftype' change purposes)
            var $editor = $(tmpls.keyform(tempkey)).data('tempkey', tempkey);

            $editor.on('submit', 'form', function (e) {
              e.preventDefault();
          
              var $this = $(this);  

              function updateKey() {          
                var tempdef = tempkey.isArray() ? tempkey.def.def : tempkey.def;
                var $key = activeRecord.$key;
                var keys = key.keys;
                var $keys = $key.closest('.keys');

                function getFormValue($val) {
                  if ($val.is('input[type=checkbox]')) {
                    return $val.prop('checked');
                  } else {
                    return $val.val();
                  }
                }

                var $vals = $this.find('input, select:not([name=type], [name=oftype])');
                for (var i = 0; i < $vals.length; i++) {
                  var $val = $vals.eq(i);

                  var name = $val.attr('name');
                  if (!name) throw new Error(); // todo: rmeove
                  if (name === 'name') {
                    tempkey[name] = $val.val();
                  } else {
                    tempdef[name] = getFormValue($val);
                  }
                }

                var errors = tempkey.errors();

                // check for duplicate names
                var dupes = key.keys.items.filter(function (item) {
                  return item !== key && item.name.toLowerCase() === tempkey.name.toLowerCase();
                });
                // and append to errors
                if (dupes.length) {
                  errors.splice(0, 0, new Msg('Duplicate key name'));
                }


                $editor.children('.alert').remove();
                if (errors.length) {  // show errors
                  $editor.prepend($(tmpls.errors(errors)));
                  return false;
                } else { // save and close
                  // update properties
                  _.extend(key, tempkey);

                  // rerender $key
                  var $newkey = createKey(key, key);
                  $key.replaceWith($newkey);
            
                  $editor.remove(); // done with this
                  dialog.hide();

                  triggerModelChanged();

                  return true;
                }
              }
              updateKey();

              return false;
            });

            // show editor
            dialog.custom({ 
              title: 'Editing key: ' + tempkey.name,
              content: $editor
            });

            return false;
          })
          .on('click', '.move-key-up, .move-key-down', function (e) {
            var $this = $(this);
            var activeRecord = $keymenu.data('active-record');
            var key = activeRecord.key;
            var $key = activeRecord.$key;
            var keys = key.keys;
            var $keys = $key.closest('.keys');
        
            // reindex keys
            var index = keys.items.indexOf(key);
            var newindex = keys.items.move(index, $this.hasClass('move-key-up') ? index - 1 : index + 1);
            $keys.insertAt(newindex, $key);

            triggerModelChanged();

            return false;
          })
          .on('click', '.delete-key', function (e) {
            e.preventDefault();

            var activeRecord = $keymenu.hide().data('active-record');
            var key = activeRecord.key;
            var $key = activeRecord.$key;
            var keys = key.keys;
        
            function deleteKey() {
              var index = keys.items.indexOf(key);
              keys.items.splice(index, 1);
              $key.remove();
              triggerModelChanged();
            }
        
            dialog.confirm({ title: 'Delete key?', message: 'Are you sure you want to delete the key [' + key.name + ']?' }, function(value) {
              if (value) {
                deleteKey();
              }
            });

            return false;
          })
          .on('click', '.key-info', function (e) {
            e.preventDefault();
            $(this).closest('.key').children('.keys').slideToggle();
            return false;
          });

          $body
          .on('submit', '.schema-editor form', function (e) {
          
            e.preventDefault();
            var $this = $(this);
            var $editor = $this.parent('.editor');
            var schema = $editor.data('schema');
            var name = $editor.find('input[name=name]').val();
            var validateName = model.validateSchemaName(name);
            if (validateName !== true) {
              $editor.find('.alert').remove();
              $editor.prepend($(tmpls.errors(validateName)));
              return false;
            }
        
            // update schema model name
            schema.name = name;

            // perform update or insert
            model.schemas.indexOf(schema) == -1 ? addSchema() : editSchema();

            function editSchema() {
              var id = schema.id;
              var $schema = $('#' + id);

              // update $schema panel heading
              $schema.find('.panel-title').text(name);

              // update any keys referencing the schema 
              $el.find('.key-header[data-ref="' + id + '"]').each(function() {
                var $this = $(this);
                var $key = $this.closest('.key');
                var key = $key.data('key');
                hideAllPopovers();
                $key.replaceWith(createKey(key));
              });
            }

            function addSchema() {
              schema.installed = !$editor.find('input[name=child]').prop('checked');
              model.insertSchema(schema);
              var $schema = $(createSchema(schema));
              $el.append($schema);
				      jsPlumb.draggable($schema, draggable);
            }

            triggerModelChanged();
            dialog.hide();
            return false;

          })
          .on('change', '.key-editor select[name=type]', function (e) {
            // type change
            var $this = $(this);
            var $editor = $this.closest('.key-editor');
            var tempkey = $editor.data('tempkey');

            // redefine key type rerender form
            var type = $this.val();
            var newDef = type === 'Array' ? {
              type: type,
              def: {
                oftype: 'String',
                def: {}
              }
            } : {
              type: type,
              def: {}
            };
        
            // redefine key def, rerender def form
            tempkey.define(newDef);
            var $def = $(tmpls[type.toLowerCase()](tempkey.def))
            $def.insertAfter($editor.find('label.key-prop:last'));
            $def.last().nextAll('label').remove();
          })
          .on('change', '.key-editor select[name=oftype]', function (e) {
            // array type change
            var $this = $(this);
            var $editor = $this.closest('.key-editor');
            var tempkey = $editor.data('tempkey');
            var def = tempkey.def;

            // redefine key oftype, rerender def form
            var type = $this.val();
            def.define({
              oftype: type,
              def: {}
            }, tempkey);
            var $def = $(tmpls.array(def))
            $def.insertAfter($editor.find('label.key-prop:last'));
            $def.last().nextAll('label').remove();
          });

        })($main);

        (function setPositionFromCookie() {
          var currentState = $.cookie('db-state') || {};
          var modelState = currentState[model.id];
          for (var id in modelState) {
            var state = modelState[id];
            var $el = $('#' + id + '.schema');
            if ($el.length) {
              $el.css({ top: state.top, left: state.left });
            } else {
            }
          }
        })();

        (function autoLayout() {
          var g = new dagre.Digraph();
          var edges = [];
          $('.schema').each(function() {
            var $this = $(this);
            var id = $(this).attr('id');
            g.addNode(id, { label: id,  width: $this.width(), height: $this.height() });
            $this.find('.key-header[data-ref]').each(function() {
              edges.push([$(this).data('ref'), id]);
            });
          });

          for (var i = 0; i < edges.length; i++) {
            g.addEdge(null, edges[i][0], edges[i][1]);
          }
          var layout = dagre.layout().nodeSep(20).edgeSep(5).rankSep(20).run(g);
          layout.eachNode(function(u, value) {
            $('#' + u).css({ top: value.y, left: value.x });
          });
        })/*()*/;

		    jsPlumb.bind('ready', function() {
				    jsPlumb.Defaults.Container = $('body');

				    var dynamicAnchors = 
						    [ 
							    [[ 0, 0.5, -1, 0 ], [ 1, 0.5, 1, 0 ]],
							    [[ 0, 0.5, -1, 0 ], [ 1, 0.5, 1, 0 ]]
						    ];


				    jsPlumb.draggable($('.schema-model .panel'), draggable);
				
				
				
            function renderConnections() {
          
              jsPlumb.detachEveryConnection();
				      $('[data-ref]').each(function() {
					
					      var $this = $(this);
					      jsPlumb.connect({
						      source: this,
						      target: $('#' + $this.data('ref')).find('.panel-heading'),
						      anchors: dynamicAnchors,
						      endpoint: 'Blank',
						      paintStyle:{ strokeStyle:'#999', lineWidth:3 },
                  overlays:[ ['PlainArrow', { location: 0, width:15, length:12, direction: -1 } ]]
                });
				      });
            }
            renderConnections();
            $main.on('modelchanged', renderConnections);
				





				    //								jsPlumb.draggable('one');
				    //				jsPlumb.draggable('two');
				    //				
				    //							var common = {
				    //					cssClass:'myCssClass'
				    //			}
				    //							jsPlumb.connect({
				    //				source:'one',
				    //				target:'four',
				    //				anchor:[ 'Continuous', { faces:['top','bottom'] }],
				    //				endpoint:[ 'Dot', { radius:5, hoverClass:'myEndpointHover' }, common ],
				    //				connector:[ 'Bezier', { curviness:100 }, common ],
				    //				overlays: [
				    //							[ 'Arrow', { foldback:0.2 }, common ],
				    //							[ 'Label', { cssClass:'labelClass' } ]    
				    //					]
				    //			});
				    //				
				    //			var e0 = jsPlumb.addEndpoint('one'),
				    //					e1 = jsPlumb.addEndpoint('four');	
				    //				jsPlumb.draggable('one');
				    //				jsPlumb.draggable('two');
				    //				jsPlumb.connect({ source:e0, target:e1,
				    //				endpoint:[ 'Rectangle', { 
				    //					cssClass:'myEndpoint', 
				    //					width:30, 
				    //					height:10 
				    //			}] });
				    //				
				
			    });

    },

    _clickToolbar: function(e) {
      if (this._editor) {
        var socket = this._socket;
        var cmds = this._editor.commands.commands;
        var actions = {
          'save': function(file, editor) {
            socket.emit('writefile', this.options.path, editor.getValue());
          },
          'validation': function(file, editor) {
            var session = editor.getSession();
            return session.setUseWorker(!session.getUseWorker());
          },
          'beautify': function(file, editor) {

            var beautifyConfig = this.options.config.beautify,
              cfg, fn;

            switch (this.options.ext) {
              case '.css':
                {
                  fn = css_beautify;
                  cfg = beautifyConfig ? beautifyConfig.css : null;
                }
                break;
              case '.html':
                {
                  fn = style_html;
                  config = beautifyConfig ? beautifyConfig.html : null;
                }
                break;
              default:
                {
                  fn = js_beautify;
                  config = beautifyConfig ? beautifyConfig.js : null;
                }
                break;
            }
            editor.setValue(fn(editor.getValue(), config));
          },
          'find': function(file, editor) {
            cmds.find.exec(editor);
          },
          'findreplace': function(file, editor) {
            cmds.replace.exec(editor);
          },
          'undo': function(file, editor) {
            cmds.undo.exec(editor);
          },
          'redo': function(file, editor) {
            cmds.redo.exec(editor);
          },
          'foldall': function(file, editor) {
            cmds.foldall.exec(editor);
          },
          'unfoldall': function(file, editor) {
            cmds.unfoldall.exec(editor);
          }
        };
        var action = $(e.currentTarget).data('action');
        (actions[action] || function() {
          alert('Action not found');
        }).call(this, null, this._editor);
      }
      return false;
    },

    _destroy: function() {
      this.element
        .removeClass('box vert');
    }
  });

  
});
