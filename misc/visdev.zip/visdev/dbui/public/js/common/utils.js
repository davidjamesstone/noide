/*global define*/

define(function () {

  return {
    getuid: function() {
      return ('' + Math.random()).replace(/\D/g, '');
    },
    getuidstr: function() {
      return (+new Date()).toString(36);
    },
    urlRoot: function() {
      var location = window.location;
      return location.protocol + '//' + location.host;
    },
    encodeString: function(str) {
      return btoa(encodeURIComponent(str));
    },  
    decodeString: function(str) {
      return decodeURIComponent(atob(str));
    },  
    getNextZIndex: function(str) {
      var $panels = $('#app .resize.panel');
      var maxZ = 0;
      $panels.each(function() {
        maxZ = Math.max(maxZ, $(this).css('z-index'));
      });
      return ++maxZ;
    }
  };

});
