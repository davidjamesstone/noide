/*global define*/

define(function () {

  return function Msg(message) {
    return {
      message: message
    };
  };

});
