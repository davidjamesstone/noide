/*global define*/

define(['jquery', 'view/tmpls'], function ($, tmpls) {

  return (function Modal() {
    var $modal = $(tmpls.modal())
      .on('click', '*[data-close]', hide)
      .appendTo(document.body);

    var $content = $modal
      .find('.modal-content')
      .eq(0);

    function show() {
      $(document.body).addClass('modalized');
    }

    function hide() {
      $modal.trigger('close');
      $(document.body).removeClass('modalized');
    }

    return {  
      show: function(content) {
        $content.children().detach();
        $content.append(content || '');
        show();
      },
      hide: function() {
        hide();
      },
      on: function(args) {
        $modal.on.apply($modal, arguments);
      },
      off: function(args) {
        $modal.off.apply($modal, arguments);
      }
    };
  })();

});
