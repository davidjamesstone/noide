/*global define*/

define(['jquery', 'view/tmpls', 'common/modal'], function ($, tmpls, modal) {

  return (function Dialog() {
    var $dialog = $(tmpls.dialog());
    var $title = $dialog.find('.dialog-title').eq(0);
    var $content = $dialog.find('.dialog-content').eq(0);

    // cache common dialogs
    var $alert = $(tmpls.alert());
    var $confirm = $(tmpls.confirm()).on('click', 'button[name=affirmative]', confirmed);
    var $prompt = $(tmpls.prompt()).on('click', 'button[name=affirmative]', confirmed);

    // singleton cb for confirm & prompt
    var callback = null;

    modal.on('close', closed);

    function closed(e) {
      if (callback) callback(false);
      clearCallback()
    }

    function confirmed(e) {
      if (callback) callback(e.delegateTarget === $prompt.get(0) ? $prompt.find('input').val().trim() : true);
      clearCallback();
      modal.hide();
    }

    function show(content) {
      $content.children().detach();
      $content.append(content || '');
      modal.show($dialog);
    }

    function setCallback(cb) {
      callback = cb;
    }

    function clearCallback() {
      callback = null;
    }

    function setTitle(options) {
      $title.html(options.title || '');
    }

    return {
      alert: function(options) {
        setTitle(options);
        $alert.find('p').html(options.message || '');
        show($alert);
      },
      confirm: function(options, cb) {
        setCallback(cb);
        setTitle(options);
        $confirm.find('p').html(options.message || '');
        show($confirm);
      },
      prompt: function(options, cb) {
        setCallback(cb);
        setTitle(options);
        $prompt.find('p').html(options.message || '');
        $prompt.find('input').attr({ placeholder: options.placeholder }).val(options.defaultValue);
        show($prompt);
      },
      custom: function(options) {
        setTitle(options);
        show(options.content);
      },
      hide: function() {
        modal.hide();
      }
    };
  })();

});
