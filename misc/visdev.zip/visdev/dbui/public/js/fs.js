/*global define */
define(['common/utils', 'common/dialog', 'plugins/file/index', 'autumn'], function (utils, dialog, fplugins) {

  var rootUrl = utils.urlRoot() + '/fs';

  var $main = $('#fs')
    , $contextMenu
    , contextFso
    , contextRoot
    , pasteBuffer
    , socket = window.io.connect(rootUrl);

  socket.on('connection', function (session) {
    var path = /[?&]path=([^&]+)/i.exec(window.location.search);
    socket.emit('addroot', path && path[1]);
  });

  // fs socket proxy handler
  function sh(f) {
    return function(rsp) {
      rsp.err 
        ? dialog.alert({ title: 'Error', message: JSON.stringify(rsp.err) }) 
        : f(rsp.data);
    }
  }
  var colorFileIcons = function($icons) {
    $icons.autumn('color', 'data-ext');
  }
  var getFsoData = function(data) {
    return data;
  };
  var addFso = function(data) {
    var html = tmpls.fso(getFsoData(data));

    var $dirs = $('.dir[data-path="' + encode(data.dir) + '"]').children('ul');
    $dirs.each(function() {
      var $dir = $(this);
      var $siblings = $dir.children('li.' + (data.isDirectory ? 'dir' : 'file'));
      if (!$siblings.length) {
        $dir[data.isDirectory ? 'prepend' : 'append'](html);
      } else {
        $siblings.each(function(index) {
          var $this = $(this);
          if ($this.find('a').text().toLowerCase() > data.name.toLowerCase()) {
            $this.before(html);
            return false;
          } else if (index === $siblings.length - 1) {
            $this.after(html);
            return false;
          }
        });
      }
    });
    colorFileIcons($dirs.find('.fso.file i.icon-file'));
  }
  var removeFso = function(data) {
    $('*[data-path="' + encode(data.path) + '"]').remove();
  }
  var showContextMenu = function(e) {

    var html = tmpls.fscontextmenu({ 
      ctx: contextFso, 
      cpy: pasteBuffer ? pasteBuffer.fso : null 
    });

    if (!$contextMenu) {
      $contextMenu = $('<div class="fs-context">').html(html).appendTo($main);
    } else {
      $contextMenu.html(html);
    }
    $contextMenu.css({ top: e.pageY, left: e.pageX }).show();
  }

  // handle socket events
  socket.on('read', sh(function (data) {
    var path = data.path;

    // find dirs to attach new data to 
    var $items = $('#' + data.crlid + ' .dir[data-path="' + encode(path) + '"]');

    if ($items.length) {
      var $replace = $(tmpls.dir(data));
      $items.replaceWith($replace);
      colorFileIcons($replace.find('.fso.file i.icon-file'));
    }
  }));
  socket.on('addroot', sh(function (data) {
    $('<ul id="' + utils.getuidstr()  + '" class="root tree">').append(tmpls.dir(getFsoData(data))).appendTo($main);
  }));
  socket.on('mkdir', sh(addFso));
  socket.on('mkfile', sh(addFso));
  socket.on('copy', sh(addFso));
  socket.on('remove', sh(function (data) {
    removeFso(data);
  }));
  socket.on('rename', sh(function (data) {
    removeFso(data[0]);
    addFso(data[1]);
  }));
  
  // handle ui events
  var sep = function(path) {
    return path.lastIndexOf('/') < 0 
      ? '\\' 
      : '/'; 
  };
  var extractFso = function($el) {
    var path = $el.path();
    var sepindex = path.lastIndexOf(sep(path));
    var dir = path.substring(0, sepindex);
    var name = path.substring(sepindex + 1, path.length);
    var isDirectory = $el.hasClass('dir');
    return { name: name, path: path, dir: dir, isDirectory: isDirectory };
  }
  var resolvePath = function(fsoResolve, name) {
    return fsoResolve.path.slice(0, fsoResolve.path.length - fsoResolve.name.length) + name;
  }
  var setActiveFso = function($el) {
    $el.addClass('active').closest('.root').find('li.fso').not($el.get(0)).removeClass('active');
  }
 
  // handle dir tree node click events
  $main
    .on('contextmenu', '.fso:not(.special) > a', function(e) {
      var $this = $(this).parent();
      e.preventDefault();
      contextFso = extractFso($this);
      contextRoot = $this.closest('.root').attr('id');
      setActiveFso($this);
      showContextMenu(e);
      return false;
    })
    .on('mouseleave', '.fs-context', function(e) { 
	    $contextMenu.hide(); 
    })
    .on('click', '.dir:not(.special) > a', function(e) {
      e.preventDefault();
      var $this = $(this).parent();
      setActiveFso($this);
      if (!$this.hasClass('loaded')) {
        socket.emit('read', $this.path(), $this.closest('.root').attr('id'));
      } else {
        $this.toggleClass('closed');
        $(this).prev().toggleClass('icon-folder-open').toggleClass('icon-folder');
      }
      return false;
    })
    .on('click', '.dir.special.git > a', function(e) {
      e.preventDefault();

      var $this = $(this).parent();
      var path = $this.path();
      var dir = $this.parent().closest('.dir').path();
      
      var href = 'http://localhost:8448/#/repository?path=' + dir;

      var $file = $('<iframe>')
      .addClass('stretch')
      .attr({ 
        src: href
      }).css({ 
        border: 'none'
      });

      //var $editor = $('<div>').ace({ 
      //  path: path, 
      //  ext: ext, 
      //  pathid: pathid 
      //});

      var $panel = $('<div>').panel({
        title: 'ungit',
        body: $file
      });


      // make schema panels draggable
      var draggable = {
        handle: '.panel-heading',
        stop: function(e, ui) {
          var pnlState = $.cookie('pnl-state') || {};
          pnlState[pathid] = ui.position;
          $.cookie('pnl-state', pnlState, { expires: 365 });
        }
      };

      $panel.appendTo($('#ws'));//.draggable(draggable);


      return false;
    })
    .on('click', '.file > a', function(e) {
      e.preventDefault();
      var href = $(this).attr('href');
      var $this = $(this).parent();
      var path = $this.path();
      var ext = $this.data('ext');
      var pathid = $this.data('path');
      var opener = 'ace';
      

      var $file = $('<iframe>')
      .addClass('stretch')
      .attr({ 
        src: href
      }).css({ 
        border: 'none'
      });

      //var $editor = $('<div>').ace({ 
      //  path: path, 
      //  ext: ext, 
      //  pathid: pathid 
      //});

      var $panel = $('<div>').panel({
        title: path,
        body: $file
      });


      // make schema panels draggable
      var draggable = {
        handle: '.panel-heading',
        stop: function(e, ui) {
          var pnlState = $.cookie('pnl-state') || {};
          pnlState[pathid] = ui.position;
          $.cookie('pnl-state', pnlState, { expires: 365 });
        }
      };

      $panel.appendTo($('#ws'));//.draggable(draggable);


      return false;
    })
    .on('click1', '.file > a', function(e) {
      e.preventDefault();
      var href = $(this).attr('href');
      var $this = $(this).parent();
      var path = $this.path();
      var ext = $this.data('ext');
      var pathid = $this.data('path');
      var opener = 'ace';
      

      var $file = $('<iframe>')
      .addClass('stretch')
      .attr({ 
        src: href
      }).css({ 
        border: 'none'
      });

      //var $editor = $('<div>').ace({ 
      //  path: path, 
      //  ext: ext, 
      //  pathid: pathid 
      //});

      var $panel = $('<div>').panel({
        title: path,
        body: $file
      });


      // make schema panels draggable
      var draggable = {
        handle: '.panel-heading',
        stop: function(e, ui) {
          var pnlState = $.cookie('pnl-state') || {};
          pnlState[pathid] = ui.position;
          $.cookie('pnl-state', pnlState, { expires: 365 });
        }
      };

      $panel.appendTo($('#ws'));//.draggable(draggable);


      return false;
    })
    .on('click', '.fs-context .fs-refresh', function(e) { 
      e.preventDefault();
      socket.emit('read', contextFso.path, contextRoot);
	    $contextMenu.hide();
    })
    .on('click', '.fs-context .fs-console', function(e) { 
      e.preventDefault();
      VD.PP.create({ 
        command: '', 
        cwd: contextFso.path 
      });
	    $contextMenu.hide(); 
    })
    .on('click', '.fs-context .fs-rename', function(e) { 
      e.preventDefault();
      dialog.prompt({ 
        title: 'Rename ' + (contextFso.isDirectory ? 'folder' : 'file'), 
        defaultValue: contextFso.name, 
        placeholder: contextFso.isDirectory ? 'Folder name' : 'File name'
      }, 
      function(value) {
        if (value) {
          socket.emit('rename', contextFso.path, contextFso.dir + sep(contextFso.dir) + value);
        }
      });
    })
    .on('click', '.fs-context .fs-remove', function(e) { 
      e.preventDefault();
      dialog.confirm({ 
        title: 'Delete ' + (contextFso.isDirectory ? 'folder' : 'file'),
        message: 'Delete [' + contextFso.name + ']. Are you sure?'
      }, 
      function(value) {
        if (value !== false) {
          socket.emit('remove', contextFso.path);
        }
      });
    })
    .on('click', '.fs-context .fs-mkdir', function(e) { 
      e.preventDefault();
      dialog.prompt({ 
        title: 'Add new folder',
        placeholder: 'Folder name'
      }, 
      function(value) {
        if (value) {
         socket.emit('mkdir', contextFso.path + sep(contextFso.path) + value);
        }
      });
    })
    .on('click', '.fs-context .fs-mkfile', function(e) { 
      e.preventDefault();
      dialog.prompt({ 
        title: 'Add new file',
        placeholder: 'File name'
      }, 
      function(value) {
        if (value) {
          socket.emit('mkfile', contextFso.path + sep(contextFso.path) + value);
        }
      });
    })
    .on('click', '.fs-context .fs-cut, .fs-copy', function(e) { 
      e.preventDefault();
      pasteBuffer = { fso: $.extend({}, contextFso), op: $(this).hasClass('fs-cut') ? 'rename' : 'copy' };
	    $contextMenu.hide(); 
    })
    .on('click', '.fs-context .fs-paste', function(e) { 
      e.preventDefault();
      socket.emit(pasteBuffer.op, pasteBuffer.fso.path, contextFso.path + sep(contextFso.path) + pasteBuffer.fso.name);
      pasteBuffer = null;
	    $contextMenu.hide(); 
    });

    
  // private methods
  var encode = utils.encodeString;
  var decode = utils.decodeString;

  // export path helper
  $.fn.path = function(value) {
    if (value) {
      this.data('path', encode(value));
    } else {
      return decode(this.data('path'));
    }
  }

});
