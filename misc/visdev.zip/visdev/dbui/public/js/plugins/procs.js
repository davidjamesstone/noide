  /*global define, window */
define(function () {

  // the terminal widget definition
  $.widget('ui.procs', {

    // default options
    options: {
      pwd: null
    },

    _onConnection: function(procs) {
      this._render(procs);
    },

    _onProcCreate: function(proc) {
      this._renderProc(proc);
    },
    
    _onProcExit: function(proc) {
    },

    // the constructor
    _create: function () {
      var self = this;
      
      this.element.addClass('procs');
      
      VD.PP.on('connection', this._onConnection.bind(this));
      VD.PP.on('create', this._onProcCreate.bind(this));
      VD.PP.on('procexit', this._onProcExit.bind(this));

    },
    
    _render: function(procs) {
      this.element.empty();
      for (var pid in procs) {
        //this.element.append($('<div>').proc({ proc: procs[pid] }));
        this._renderProc(procs[pid]);
      }
    },
    
    _renderProc: function(proc) {

      var id = this.uuid;
      
      var $proc = $('<iframe>')
      .addClass('stretch')
      .attr({ 
        src: '/proc#' + proc.pid
      }).css({ 
        border: 'none'
      });

      var $panel = $('<div>').panel({
        title: proc.pid,
        body: $proc
      });


      // make panels draggable
      //var draggable = {
      //  handle: '.panel-heading',
      //  stop: function(e, ui) {
      //    var pnlState = $.cookie('pnl-state') || {};
      //    pnlState[id] = ui.position;
      //    $.cookie('pnl-state', pnlState, { expires: 365 });
      //  }
      //};

      $panel.appendTo($('#ws'));//.draggable(draggable);


      //this.element.append();
    },

    // revert modifications
    _destroy: function () {
      // remove generated elements
      this.element.removeClass('procs').empty();
    }

  });


});
