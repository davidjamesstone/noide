  /*global define, window */
define(['jqueryconsole', 'jquerymigrate'], function () {


  // the terminal widget definition
  $.widget('ui.proc', {

    // default options
    options: {
      pwd: null
    },

    // the constructor
    _create: function () {
      this.element.addClass('box vert');

      var proc = this.options.proc
        , socket = proc.socket
        ;

      socket.on('connect', function () {

        var $console = $('<div>').addClass('console stretch').appendTo(this.element);
        var jqconsole = $console.jqconsole('', '');

        var startPrompt = function () {

          // start the prompt with history enabled
          jqconsole.Prompt(true, function (input) {
            socket.emit('data', input);
          });
        };

        // Ctrl+C: resets the console 
        jqconsole.RegisterShortcut('c', function() {
          socket.emit('signal', 'SIGINT');
        });  
        // Ctrl+D: quit the console 
        jqconsole.RegisterShortcut('c', function() {
          socket.emit('signal', 'SIGQUIT');
        });  

        startPrompt();

        

        socket.on('data', function (data) {
          jqconsole.Write(data);
          startPrompt();
        });
        socket.on('error', function (data) {
          jqconsole.Write(data, 'jqconsole-error');
          startPrompt();
        });
        socket.on('exit', function (data) {
          jqconsole.Write(data);
          this.element.trigger('exit');
        }.bind(this));

      }.bind(this));
    },

    // revert modifications
    _destroy: function () {
      // remove generated elements
      alert('')
      this.element.removeClass('console').empty();
    }
  });

});
