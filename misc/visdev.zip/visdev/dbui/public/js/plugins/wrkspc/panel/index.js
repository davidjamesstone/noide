define(['common/utils'], function(utils) {

  return {
    // default options
    options: {
      title: null,
      body: null,

      // callbacks
      change: null
    },

    // the constructor
    _create: function() {

      this.element
        .attr('id', this.uuid)
        .addClass('resize panel')
        .css({
          zIndex: utils.getNextZIndex()
        })
        .html(tmpls.panel({
          title: this.options.title
        }));


      this._$heading = this.element.find('.panel-heading');
      this._$title = this.element.find('.panel-title');
      this._$body = this.element.find('.stretch');

      this._$body.html(this.options.body);

      // bind drag and drop events
      var draggable = this.element.attr('draggable', true).get(0);
      var handle = this._$heading.get(0);
      var target = false;
      var coords = null;
      
      this._on(this.element, {
        'click[data-close]': function(e) {
          this.destroy();
        }
      });

      this._on(this.element, {
        'mousedown': function(e) {
          target = e.target;
        }
      });

      this._on(this.element, {
        'dragstart': function(e) {
          if (handle.contains(target)) {
            
            var top = e.clientY,
              left = e.clientX,
              event = e.originalEvent;

            //event.dataTransfer.effectAllowed       = 'move';
            var style = window.getComputedStyle(event.target, null);
            coords = event.screenX + ',' + event.screenY;
            event.dataTransfer.setData("text/plain", coords);
          } else {
            e.preventDefault();
          }
        }
      });


      this._on(this.element, {
        'dragend': function(e) {
          e.preventDefault();

          var event = e.originalEvent;
          var offset = coords.split(',');
          var dm = draggable;
          var style = window.getComputedStyle(event.target, null);
          var left = parseInt(style.left, 10);
          var top = parseInt(style.top, 10);
          var dx = (event.screenX) - offset[0];
          var dy = (event.screenY) - offset[1];
          var l2 = isNaN(left) ? (Math.max(0, dx)) + 'px' : Math.max(0, (dx + left)) + 'px';
          var t2 = isNaN(top) ? (Math.max(0, dy)) + 'px' : Math.max(0, (dy + top)) + 'px';

          dm.style.left = l2;
          dm.style.top = t2;

          return false;
        }
      });

    },

    _destroy: function() {
      this.element.remove();
    }
  };
});