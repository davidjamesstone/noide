define(['require', './panel/index'], function (require, panel) {

  $.widget("vui.panel", panel);
  
  //var cssUrl = require.toUrl("./codemirror/lib/codemirror.css");

  // return an config object that describes file ui information
  // default opener, matching function (.ext, name etc), widget default options, stylesheets(?) etc
  // 
  return {
    //css: [cssUrl]
  };

});