define(['common/utils', 'text!./config.json'], function(utils, config) {
  return {
    options: {
      config: JSON.parse(config || {}),
      path: null,
      dir: null,
      name: null,
      ext: null
    },

    _create: function() {

      var options = this.options,
        config = options.config.editor || {}, 
        path = options.path,
        ext = options.ext || '';


      // -- initialize element
      this.element.addClass('box vert');
      this.element.append(tmpls.ace());

      // -- initialize editor --
      var $editor = this.element.find('.ace'),
        editor = this._editor = ace.edit($editor.get(0)),
        session = editor.getSession();

      editor.setOptions({
        enableBasicAutocompletion: true,
        enableSnippets: true
      });

      var mode = config.modes[options.ext.toLowerCase()] || 'ace/mode/asciidoc';
      session.setMode(mode);

      editor.setTheme(config.theme || 'ace/theme/monokai');

      if (typeof config.showPrintMargin === 'boolean') editor.setShowPrintMargin(config.showPrintMargin);
      if (typeof config.highlightActiveLine === 'boolean') editor.setHighlightActiveLine(config.highlightActiveLine);
      if (typeof config.showGutter === 'boolean') editor.renderer.setShowGutter(config.showGutter);
      if (typeof config.tabSize === 'number') session.setTabSize(config.tabSize);
      if (typeof config.useSoftTabs === 'boolean') session.setUseSoftTabs(config.useSoftTabs);
      if (config.fontSize) editor.setFontSize(config.fontSize);

      editor.commands.addCommands([{
          name: 'save',
          bindKey: {
            win: 'Ctrl-S',
            mac: 'Command-S'
          },
          exec: function(editor, line) {
            socket.emit('writefile', path, editor.getValue());
          },
          readOnly: true
        }
      ]);

      // -- toolbar
      this._on(this.element, {
        'click .toolbar a': this._clickToolbar
      });


      // -- initialize file ns socket

      var rootUrl = utils.urlRoot() + '/fs',
        socket = window.io.connect(rootUrl);

      this._socket = socket;
      socket.on('connection', function() {
        socket.on('readfile', function(rsp) {
          console.log('readfile');
          session.setValue(rsp.data.contents);
        });
        socket.on('writefile', function(rsp) {
          if (rsp.err) {
            dialog.alert({
              title: rsp.data.path,
              message: 'Write Failed'
            });
          } else {
            session.getUndoManager().markClean();
          }
        });
        console.log('emit readfile');
        socket.emit('readfile', path);

      });


    },

    _clickToolbar: function(e) {
      if (this._editor) {
        var socket = this._socket;
        var cmds = this._editor.commands.commands;
        var actions = {
          'save': function(file, editor) {
            socket.emit('writefile', this.options.path, editor.getValue());
          },
          'validation': function(file, editor) {
            var session = editor.getSession();
            return session.setUseWorker(!session.getUseWorker());
          },
          'beautify': function(file, editor) {

            var beautifyConfig = this.options.config.beautify,
              cfg, fn;

            switch (this.options.ext) {
              case '.css':
                {
                  fn = css_beautify;
                  cfg = beautifyConfig ? beautifyConfig.css : null;
                }
                break;
              case '.html':
                {
                  fn = style_html;
                  config = beautifyConfig ? beautifyConfig.html : null;
                }
                break;
              default:
                {
                  fn = js_beautify;
                  config = beautifyConfig ? beautifyConfig.js : null;
                }
                break;
            }
            editor.setValue(fn(editor.getValue(), config));
          },
          'find': function(file, editor) {
            cmds.find.exec(editor);
          },
          'findreplace': function(file, editor) {
            cmds.replace.exec(editor);
          },
          'undo': function(file, editor) {
            cmds.undo.exec(editor);
          },
          'redo': function(file, editor) {
            cmds.redo.exec(editor);
          },
          'foldall': function(file, editor) {
            cmds.foldall.exec(editor);
          },
          'unfoldall': function(file, editor) {
            cmds.unfoldall.exec(editor);
          }
        };
        var action = $(e.currentTarget).data('action');
        (actions[action] || function() {
          alert('Action not found');
        }).call(this, null, this._editor);
      }
      return false;
    },

    _destroy: function() {
      this.element
        .removeClass('box vert');
    },

    // public
    editor: function() {
      return this._editor;
    }
  };
});