(function ($) { "use strict";

  // APP CLASS DEFINITION
  // ======================

  var App = function (el) {
    $(el).on('click', '.box', this.boxClick);
  }
  
  App.prototype.boxClick = function (e) {
    var $this = $(this);
    var options = $this.data('app-component');
    var type = options.type;

    $this[type](options);

  }

  App.prototype.insert = function (options, index) {
    var $this = $(this);
    var $newcmp = $(tmpls.component(options)).data('app-component', options.data);
    $this.insertAt(index || 0, colorAppItems($newcmp));
    console.log(JSON.stringify(options), index);    
  }

  
  var colorAppItems = function($items) {
    return $items.autumn('backgroundColor', 'data-color');
  }

  // APP PLUGIN DEFINITION
  // =======================


  $.fn.app = function (option) {
    var args = Array.prototype.slice.call(arguments, 1);
    return this.each(function () {
      var $this = $(this);
      var data  = $this.data('app');

      if (!data) $this.data('app', (data = new App(this)));
      if (typeof option == 'string') data[option].apply($this, args);
    });
  }

  $.fn.app.Constructor = App
  
  // APP DATA-API
  // ==============

 // $(document).on('click.bs.app.data-api', dismiss, App.prototype.close)

})(jQuery);








//  //.resizable().on('resize', function () { console.log('sds') });


//    //$main.find('.box').resizable({
//    //  stop: function( event, ui ) {
//    //    //console.log('sds'); execMasonry();
//    //  }
//    //});


//  var execMasonry = function() {
//    var msnry = new Masonry($main.get(0), {
//      // options
//      //columnWidth: 100,
//      animate: true
//    });
//    colorAppItems($main.find('.box'));
//  }

//  var colorAppItems = function($items) {
//    $items.autumn('backgroundColor', 'data-color');
//  }

//  //// trigger masonry
//  //$main.masonry({
//  //  columnWidth: 100,
//  //  animate: true
//  //});

//  //$('.box').click(function() {
//  //  var $this = $(this),
//  //      size = $this.hasClass('large') ?
//  //        { width: 90, height: 90 } :
//  //        { width: 190, height: 190 };
//  //  $this.toggleClass('large').animate( size, execMasonry );
//  //});

//  colorAppItems($app.find('.box'));
////  execMasonry();