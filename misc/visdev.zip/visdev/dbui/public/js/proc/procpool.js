﻿  /*global define, window */
define(['common/utils'], function (utils) {

  var rootUrl = utils.urlRoot() + '/pp';

  function ProcPool() {

    var self = this
      , socket
      , procs = {}
      ;

    this.socket = null;
    this.connect = function() {

      this.socket = socket = window.io.connect(rootUrl);

      socket
        .on('connection', function (data) {
          procs = {};
          for (var i = 0; i < data.length; i++) {
            var proc = new Proc(data[i]);
            procs[data[i]] = proc;
          }
          listeners('connection').fire(procs);
        })
        .on('create', function (data) {
          var proc = new Proc(data);
          
          proc.socket.on('exit', function (data) {
            delete procs[proc.pid];
          });

          procs[data] = proc;
          listeners('create').fire(proc);
        })
        .on('kill', function (data) {
          var proc = new Proc(data);
          if (delete procs[data.pid]) {
            listeners('kill').fire(data.pid);
          }
        });
    
      return socket;

    };

    this.getProcs = function() {
      return procs;
    }

    var _listeners = {};
    function listeners(event) {
      return event 
        ? _listeners[event] || (_listeners[event] = $.Callbacks()) 
        : _listeners;
    }
    this.on = function(event, fn) {
      listeners(event).add(fn);
    }
    this.off = function(event, fn) {
      listeners(event).remove(fn);
    }
  }
  ProcPool.prototype.create = function(command) {
    this.socket.emit('create', command);
  };
  ProcPool.prototype.factoryProc = function(pid) {
    return new Proc(pid);
  };
  
  function Proc(pid) {
    this.pid = pid;
    this.socket = window.io.connect(rootUrl + '/' + pid);
  }
  Proc.prototype.write = function(data) {
    this.socket.emit('data', data);
  };

  return new ProcPool();

});
