/*global require*/

require.config({
  baseUrl: 'js',
  paths: {
    'jquery': '../components/jquery/jquery',
    'jquerycookie': '../components/jquery.cookie/jquery.cookie',
    'jqueryui': 'http://ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/jquery-ui.min',
    'jquerymigrate': 'http://code.jquery.com/jquery-migrate-1.2.1.min',
    'jqueryconsole': '../components/jquery.console/jqconsole',
    'underscore': '../components/underscore/underscore',
    'text': '../components/requirejs/text',
    'socket': '/socket.io/socket.io',
    'procpool': 'proc/procpool',
    'jsplumb': '../components/jquery.plumb/jquery.jsPlumb-1.5.5-min',
    'autumn': 'https://raw.github.com/nluqo/autumn/master/autumn',
    'masonry': '../components/masonry/masonry.pkgd',
    'model': 'model',
    'appl': 'plugins/app',
    'view': 'view',
    'common': 'common',
    'helpers': 'common/helpers',
    'html': '../html',
    'ace': 'plugins/file/ace/lib/ace'
  },
  shim: {
    underscore: {
      exports: '_'
    },
    jqueryui: {
      deps: ['jquery']
    },
    jqueryconsole: {
      deps: ['jquery']
    },
    jquerymigrate: {
      deps: ['jquery']
    },
    jquerycookie: {
      deps: ['jquery']
    },
    jsplumb: {
      deps: ['jquery']
    },
    autumn: {
      deps: ['jquery']
    },
    masonry: {
      deps: ['jquery']
    },
    app: {
      deps: ['jquery']
    },
    helpers: {
      deps: ['jquery']
    }
  }
});

require(['main']);