dir-read,rename,delete,move,copy,addfile,adddir
file-read,rename,delete,move,copy,savefile

var f = require('C:\\Projects\\Node\\visdev\\dbui\\lib\\fileutils.js');
var cns = function(err, data) { console.log(err ?? data); }

// read dir
f.readdir('C:\\Projects\\Node\\sock\\test_io', cns)

//make dir
f.mkdir('C:\\Projects\\Node\\sock\\test_io\\sid', cns)

// rename dir
f.rename('C:\\Projects\\Node\\sock\\test_io\\sid', 'C:\\Projects\\Node\\sock\\test_io\\lid', cns)


// write file
f.writeFile('C:\\Projects\\Node\\sock\\test_io\\lid\\ron.txt', cns)

// rename file
f.rename('C:\\Projects\\Node\\sock\\test_io\\lid\\ron.txt', 'C:\\Projects\\Node\\sock\\test_io\\lid\\bon.txt', cns)


// copy file
f.copy('C:\\Projects\\Node\\sock\\test_io\\lid\\bon.txt', 'C:\\Projects\\Node\\sock\\test_io\\lid\\don.txt', cns)


// copy directory
f.copy('C:\\Projects\\Node\\sock\\test_io\\lid', 'C:\\Projects\\Node\\sock\\test_io\\sid', cns)

// remove file
f.remove('C:\\Projects\\Node\\sock\\test_io\\lid\\don.txt', cns)


// remove directory
f.remove('C:\\Projects\\Node\\sock\\test_io\\lid', cns)

// rename file
f.rename('C:\\Projects\\Node\\sock\\test_io\\sid\\bon.txt', 'C:\\Projects\\Node\\sock\\test_io\\ron.txt', cns)

// remove file
f.remove('C:\\Projects\\Node\\sock\\test_io\\ron.txt', cns)

// make copy destination
f.mkdir('C:\\Projects\\Node\\sock\\test_io\\emily', cns)

// rename dir
f.rename('C:\\Projects\\Node\\sock\\test_io\\sid', 'C:\\Projects\\Node\\sock\\test_io\\emily\\sid', cns)

// remove directory
f.remove('C:\\Projects\\Node\\sock\\test_io\\emily', cns)



pie jesu
armed man carl jenkins
in the bleak mi winter x 2 (SoP, Boys Choir)
























var cns = function(rsp) { rsp ? console.log(rsp.err || rsp.data) : 'no rsp';  }
socket.on('fs-read', cns);
socket.on('fs-mkdir', cns);
socket.on('fs-rename', cns);
socket.on('fs-copy', cns);
socket.on('fs-remove', cns);
socket.on('fs-write-file', cns);

// read dir
socket.emit('fs-read', 'C:\\Projects\\Node\\sock\\test_io')

//make dir
socket.emit('fs-mkdir', 'C:\\Projects\\Node\\sock\\test_io\\sid')

// rename dir
socket.emit('fs-rename', 'C:\\Projects\\Node\\sock\\test_io\\sid', 'C:\\Projects\\Node\\sock\\test_io\\lid')


// write file
socket.emit('fs-write-file', 'C:\\Projects\\Node\\sock\\test_io\\lid\\ron.txt')

// rename file
socket.emit('fs-rename', 'C:\\Projects\\Node\\sock\\test_io\\lid\\ron.txt', 'C:\\Projects\\Node\\sock\\test_io\\lid\\bon.txt')


// copy file
socket.emit('fs-copy', 'C:\\Projects\\Node\\sock\\test_io\\lid\\bon.txt', 'C:\\Projects\\Node\\sock\\test_io\\lid\\don.txt')


// copy directory
socket.emit('fs-copy', 'C:\\Projects\\Node\\sock\\test_io\\lid', 'C:\\Projects\\Node\\sock\\test_io\\sid')

// remove file
socket.emit('fs-remove', 'C:\\Projects\\Node\\sock\\test_io\\lid\\don.txt')


// remove directory
socket.emit('fs-remove', 'C:\\Projects\\Node\\sock\\test_io\\lid')

// rename file
socket.emit('fs-rename', 'C:\\Projects\\Node\\sock\\test_io\\sid\\bon.txt', 'C:\\Projects\\Node\\sock\\test_io\\ron.txt')

// remove file
socket.emit('fs-remove', 'C:\\Projects\\Node\\sock\\test_io\\ron.txt')

// make copy destination
socket.emit('fs-mkdir', 'C:\\Projects\\Node\\sock\\test_io\\emily')

// rename dir
socket.emit('fs-rename', 'C:\\Projects\\Node\\sock\\test_io\\sid', 'C:\\Projects\\Node\\sock\\test_io\\emily\\sid')

// remove directory
socket.emit('fs-remove', 'C:\\Projects\\Node\\sock\\test_io\\emily')