/**
 * Module dependencies.
 */

var express = require('express')
    , mers = require('mers')
    , mongoose = require('mongoose')
    , db = require('../dbgen/lib/generators/mongo')(mongoose)
    , dbdata = require('../egg.json')
    , schemas = null
    , models = null;

var app = module.exports = express();

// setup 

db.connect('mongodb://localhost/dbtest');
schemas = db.generateSchemas(dbdata);
models = db.generateModels(schemas);
console.log(schemas);
    
// configuration
app.configure(function () {
  app.use(express.bodyParser());
  app.use(express.methodOverride());

  app.get('/', function (req, res, next) {
      console.log('here I am')
      req.query.transform = function (v) {
          console.log('HELLO', v);

          return  {vid:v._id, junk:true};
      }
      req.url = '/api/Customer/'
      next();
  });
    
  app.get('/test', function (req, res) {
      console.log('here I am')

      models.p
      .findOne()
      .populate('fk')
      .exec(function (err, p) {
        if (err) throw err;
        res.send(p.toJSON());
      })
  });

  app.use('/api', mers({ mongoose: mongoose }).rest());
    
//var c2 = new (mongoose.model('C2g'))({
//  stringField1: 'Zildjian',
//  dateField1: Date.now(),
//  booleanField1: true
//});

//kitty.referencedSchemaArrayField.push({ stringField2: '80 Moss Road'});

//c2.save(function(err) {
//  if (err) {
//    console.log(err);
//  } else {
//    console.log(c2);
//  }
//});



    app.use(express.errorHandler({ dumpExceptions:true, showStack:true }));

});
app.listen(3000)




module.exports = app;