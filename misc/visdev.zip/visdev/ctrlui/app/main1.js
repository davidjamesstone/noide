// to depend on a bower installed component:
// define(['component/componentName/file'])

define(['jquery', 'knockout', 'underscore', 'bootstrap'], function($, ko, _) {
	
	window.ko = ko;
		
	Controller = function(data) {
		this.name = ko.observable(data.name);
		this.code = ko.observable(data.code);
		this.actions = ko.observableArray(data.actions);
		this.addAction = function() {
			this.actions.push(new Action({ name: '<action name>', url: '/' + this.name().toLowerCase(), code: 'function(req, res) {\n}' }));
		};
		this.displayed = ko.observable();
		this.toggleDisplayed = function() {
			this.displayed(!this.displayed());
		};
		this.hasActionDisplayed = ko.computed(function() {
			console.log('hasActionDisplayed');
			return _.find(this.actions(), function(item) { return item.displayed(); });
		}.bind(this));
	};	

	Action = function(data) {
		this.name = ko.observable(data.name);
		this.url = ko.observable(data.url);
		this.method = ko.observable(data.method);
		this.code = ko.observable(data.code);
		this.middleware = ko.observableArray(data.middleware);
		this.displayed = ko.observable();
		this.toggleDisplayed = function() {
			this.displayed(!this.displayed());
		};
	};
	
	Middleware = function(data) {
		this.name = ko.observable(data.name);
		this.code = ko.observable(data.code);
	};
	
	Controllers = function() {
		this.controllers = ko.observableArray();
		this.hasControllerDisplayed = ko.computed(function() {
			console.log('hasControllerDisplayed');
			return _.find(this.controllers(), function(item) { return item.displayed(); })
		}.bind(this));
	};
	
	// initialize bindings
	c = new Controllers();
	ko.applyBindings(c, $('html')[0]);
	
	
	function makeController() {
		return new Controller({ 
			name: 'Customer', 
			code: 'function a(){}', 
			actions: [
				new Action({ url: '/customer', name: 'index', method: 'GET', code: 'function a(){}' }),
				new Action({ url: '/customer/new', name: 'new', method: 'GET', code: 'function a(){}' }),
				new Action({ url: '/customer', name: 'create', method: 'POST', code: 'function a(){}' }),
				new Action({ url: '/customer/:id', name: 'show', method: 'GET', code: 'function a(){}' }),
				new Action({ url: '/customer/:id/edit', name: 'edit', method: 'GET', code: 'function a(){}' }),
				new Action({ url: '/customer/:id', name: 'update', method: 'PUT', code: 'function a(){}' }),
				new Action({ url: '/customer/:id', name: 'destroy', method: 'DELETE', code: 'function a(){}' })
			]
		});
	}

c.controllers.push(makeController());
c.controllers.push(makeController());
c.controllers.push(makeController());
c.controllers.push(makeController());
	
	
	
});
