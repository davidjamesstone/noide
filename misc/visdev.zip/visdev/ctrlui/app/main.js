// to depend on a bower installed component:
// define(['component/componentName/file'])

define(['jquery', 'knockout', 'underscore', 'bootstrap'], function($, ko, _) {
  $.getJSON('/test.json', function(data) {
    
    
    var KeyDef = function() {
      this.initialize = function(data) {
        this.type = ko.observable(data.type);
        this.required = ko.observable(data.required);
        return this;
      };
    };	
    
    var DummyKeyDef = function(data) {
      var self = this.initialize(data);
    };	
    KeyDef.call(DummyKeyDef.prototype);	
    
    var StringKeyDef = function(data) {
      var self = this.initialize(data);
      self.enumeration = ko.observable(data.enum);
      self.uppercase = ko.observable(data.uppercase);
      self.lowercase = ko.observable(data.lowercase);
      self.match = ko.observable(data.match);
      self.trim = ko.observable(data.trim);	
      self.defaultValue = ko.observable(data.default);	
    };
    KeyDef.call(StringKeyDef.prototype);
    
    var BooleanKeyDef = function(data) {
      var self = this.initialize(data);
      self.defaultValue = ko.observable(data.default);
      self.availableDefaults = [ 
        { name: 'undefined', value: undefined }, 
        { name: 'true', value: true }, 
        { name: 'false', value: false } 
      ];
    };	
    KeyDef.call(BooleanKeyDef.prototype);	
    
    var DateKeyDef = function(data) {
      var self = this.initialize(data);
      self.defaultValue = ko.observable(data.default);
    };
    KeyDef.call(DateKeyDef.prototype);
    
    var NumberKeyDef = function(data) {
      var self = this.initialize(data);
      self.min = ko.observable(data.min);
      self.max = ko.observable(data.max);
      self.defaultValue = ko.observable(data.default);	
    };
    KeyDef.call(NumberKeyDef.prototype);
    
    var ObjectIdKeyDef = function(data) {
      var self = this.initialize(data);
      self.ref = ko.observable(data.ref);
      self.auto = ko.observable(data.auto);
    };
    KeyDef.call(ObjectIdKeyDef.prototype);
    
    var ArrayKeyDef = function(data) {
      var self = this.initialize(data);
    };
    KeyDef.call(ArrayKeyDef.prototype);
    
    var SimpleTypedArrayKeyDef = function(data) {
      var self = this.initialize(data);
      self.subdef = ko.observable(factoryKeyDef(data.key));          
    };
    KeyDef.call(SimpleTypedArrayKeyDef.prototype);

    var ReferencedSchemaArrayKeyDef = function(data) {
      var self = this.initialize(data);
      self.ref = ko.observable(data.key.ref);
      
      // type definition change handling
      self.redefine = ko.observable();
      self.redefine.subscribe(function(value) {
        self.ref(value);
      });          
    };
    KeyDef.call(ReferencedSchemaArrayKeyDef.prototype);    
    
    function factoryKeyDef(data) {
      var type = data.type ? data.type.toLowerCase() : undefined;
      switch (type) {
        case undefined:
          return new Keys(data.keys.items);
          //				case 'ref':
          //					o = shared[v.ref];
          //					break;
        case 'string':
          return new StringKeyDef(data);
        case 'date':
          return new DateKeyDef(data);
        case 'number':
          return new NumberKeyDef(data);
        case 'boolean':
          return new BooleanKeyDef(data); 
        case 'array':
          if (data.key) {
            return (data.key.type === 'ref' ? 
              new ReferencedSchemaArrayKeyDef(data) : 
              new SimpleTypedArrayKeyDef(data));
          } else if (data.keys) {
            return new Keys(data.keys.items); 
          } else {
            return new ArrayKeyDef(data);
          }
          break;
        case 'objectid':
          return new ObjectIdKeyDef(data);
        case 'mixed':
          return new DummyKeyDef(data); 
        case 'buffer':
          return new DummyKeyDef(data); 
        default:
          return new DummyKeyDef(data); 
          //throw new Error('Type not supported');
      }
    }
    
    function getKeyDefTpl(data) {
      if (data instanceof Keys) {
        return { name: 'keys-tpl', data: data }; // owned sub schema
      } else if (data instanceof SimpleTypedArrayKeyDef) {
        return { name: 'simple-typed-array-key-def-tpl', data: data };
      } else if (data instanceof ReferencedSchemaArrayKeyDef) {
        return { name: 'referenced-schema-array-key-def-tpl', data: data };
      } else {
        switch (data.type().toLowerCase()) {
          case 'string':
          case 'number':
          case 'boolean':
          case 'date':
          case 'objectid':
            return { name: data.type().toLowerCase() + '-key-def-tpl', data: data };
          default:
            return { name: 'key-def-tpl', data: data };
        }
      }
    }
    
    var Key = function(name, data) {
      var self = this;
      self.name = ko.observable(name);
      self.def = ko.observable(factoryKeyDef(data));
      self.description = ko.computed(function() {
        var def = self.def();
        var type = def.type;
        if (type) {
          var t = type();
          if (t === 'Array') {
            if (def.subdef) {
              if (def.subdef().type() === 'ObjectId' && def.subdef().ref()) {
                return '[' + def.subdef().type() + '<' + def.subdef().ref() + '>]';
              } else {
                return '[' + def.subdef().type() + ']';
              }
            } else if (def.keys) {
              return '[{}]';
            } else {
              return '[{*}]';
            }
          } else if (t === 'ObjectId' && def.ref()) {
            return t + '<' + def.ref() + '>';
          } else {
            return t;
          }
        }
        return '{}';
      }, this);
      self.showDefinition = ko.observable(false);
      self.toggleDefinition = function() {
        self.showDefinition(!self.showDefinition());
      };
      
      // type definition change handling
      self.redefine = ko.observable();
      self.redefine.subscribe(function(value) {
        self.def(value);
      });
    };
    
    var Keys = function(keys) {
      var self = this;
      self.items = ko.observableArray();
      self.addKey = function() {
          self.items.push(new Key('NEW', { type: 'String' }));
      };
      _.each(keys, function(value, key) {
        self.items.push(new Key(key, value));
      });	
    };
    
    var Schema = function(name, data) {
      var self = this;
      self.name = ko.observable(name);
      self.installed = ko.observable(data.installed);
      self.keys = new Keys(data.keys.items);
    };
    
    var Db = function(db) {
      var self = this;
      self.schema = ko.observableArray();     
      self.getKeyDefTpl = getKeyDefTpl;

      var staticTypes = 'String Boolean Date Number Array Buffer NestedDocument Mixed ObjectId'.split(' '); staticTypes.sort();
      var staticTypeDefs = _.map(staticTypes, function(item) {
        return {
          name: item,
          value: { type: item }
        };
      });
      var staticTypeArrayDefs = _.map(_.filter(staticTypes, function(item) { return item !== 'Array' }), function(item) {
        return {
          name: '[' + item + ']',
          value: { type: 'Array', key: { type: item } }
        };
      });
      var notInstalledSchemas = function() {
        return _.filter(self.schema(), function(schema) { return !schema.installed(); });  
      };
      var installedSchemas = function() {
        return _.filter(self.schema(), function(schema) { return schema.installed(); });  
      };
      var foreignKeyDefs = function() {
        return _.map(installedSchemas(), function(schema) { 
          return {
            name: 'ObjectId<' + schema.name() + '>',
            value: { type: 'ObjectId', ref: schema.name() }
          };
        });  
      };
      var foreignKeyArrayDefs = function() {
        return _.map(installedSchemas(), function(schema) { 
          return {
            name: '[ObjectId<' + schema.name() + '>]',
            value: { type: 'Array', key: { type: 'ObjectId', ref: schema.name() } }
          };
        });  
      };
      var childSchemaArrayDefs = function() {
        return _.map(notInstalledSchemas(), function(schema) { 
          return {
            name: '[' + schema.name() + ']',
            value: { type: 'Array', key: { type: 'ref', ref: schema.name() } }
          };
        });  
      };
      self.availableDefs = ko.computed(function() {      
        return [].concat(staticTypeDefs, foreignKeyDefs(), staticTypeArrayDefs, foreignKeyArrayDefs(), childSchemaArrayDefs());
      }, this);


      // add schemas to db
      _.each(db, function(value, key) {
        self.schema.push(new Schema(key, value));
      });
       
    };
    
    // initialize bindings
    ko.applyBindings(new Db(data), $('html')[0]);
    
    
  });
});
