require.config({
  // make components more sensible
  // expose jquery 
  paths: {
    'components': '../bower_components',
    'jquery': '../bower_components/jquery/jquery',
    'knockout': '../bower_components/knockout/build/output/knockout-latest',
    'underscore': '../bower_components/underscore/underscore',
    'bootstrap': '../bower_components/bootstrap/dist/js/bootstrap',
		'jsplumb': 'https://raw.github.com/sporritt/jsPlumb/master/dist/js/jquery.jsPlumb-1.5.3',
		'jqueryui': 'http://ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/jquery-ui.min'
  },
  shim: {
    underscore: {
      exports: '_'
    },
    backbone: {
      deps: ['underscore', 'jquery'],
      exports: 'Backbone'
    },
    jqueryui: {
      deps: ['jquery']
    },
    bootstrap: {
      deps: ['jquery']
    }
  }	
});

// Use the debug version of knockout it development only
// When compiling with grunt require js will only look at the first 
// require.config({}) found in this file
require.config({
  paths: {
    'knockout': '../bower_components/knockout/build/output/knockout-latest.debug'
  }
});

if (!window.requireTestMode) {
  require(['main1'], function(){ 
		console.log('Main application loaded');
	});
}

