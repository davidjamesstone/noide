var mongoose = require('mongoose');
var Schema = mongoose.Schema;
mongoose.connect('mongodb://localhost/teste');

var Cat = mongoose.model('Cat', { name: 'Buffer' });

var kitty = new Cat({
  name: 'asasa' });



var c = new Schema({
  cname: {
    type: String,
    required: true,
    trim: true
  }
});
mongoose.model('c', c);

var b = new Schema({
  bname: {
    type: String,
    required: true,
    trim: true
  }
});
mongoose.model('b', b);

var a = new Schema({
  aname: {
    type: String,
    required: true,
    trim: true
  },
  fk: {
    type: Schema.ObjectId,
    ref: 'b'
  },
  myC: c
});

mongoose.model('a', a);
//
// kitty.save(function (err) {
//   if (err) console.log(err);
//   console.log('meow');
// });



// function getType(v) {
//   switch (v.type.toLowerCase()) {
//     case 'string':
//       return String;
//     case 'date':
//       return Date;
//     case 'number':
//       return Number;
//     case 'boolean':
//       return Number;
//     case 'array':
//        return Array;
//     case 'objectid':
//       return mongoose.Types.ObjectId;
//     case 'mixed':
//       return mongoose.Types.Mixed;
//     case 'Buffer':
//       return mongoose.Types.Buffer;
//     default:
//       throw new Error('Type not supported');
//   }
// }
