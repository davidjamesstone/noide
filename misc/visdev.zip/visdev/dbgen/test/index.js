_ = require('underscore');

var mongoose = require('mongoose');
var db = require('../lib/generators/mongo')(mongoose);
var dbdata = require('../../egg.json');

db.connect('mongodb://localhost/dbtest', {});
var schemas = db.generateSchemas(dbdata);
var models = {};

// build models
for (var name in schemas) {
  models[name] = mongoose.model(name, schemas[name]);
}

// log paths
for (var name in models) {
  models[name].schema.eachPath(function(path) { console.log(path); });
}


var kitty = new models.C1({
  stringField: 'Zildjian'
});

kitty.referencedSchemaArrayField.push({ stringField2: '80 Moss Road'});

kitty.save(function(err) {
  if (err) {
    console.log(err);
  } else {
    console.log(kitty);
  }
});


console.log('end');
